#pragma once

#ifndef MAINHEADER

#define MAINHEADER
#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include <limits.h>
#include "MinHeapHeader.h"
#include "GraphHeader.h"
#include "DijkstraHeader.h"

#endif